package com.example.studentprofilemanagementsystem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView

class SplashScreen : AppCompatActivity() {

    private var i=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val pgsBar = findViewById<ProgressBar>(R.id.pBar)
        val txtView = findViewById<TextView>(R.id.tView)

        Handler(Looper.getMainLooper()).postDelayed(
            {
                val i = Intent(this, Login_Page::class.java)
                startActivity(i)
                finish() },2000 )

        i = pgsBar.progress
        Thread{
            while(i<100){
                i = i+1

                Handler(Looper.getMainLooper()).post{
                    pgsBar.progress = i
//                    txtView.text = i.toString() + "/" + pgsBar.max
                    txtView.text = i.toString() + "%"
                }
                try{
                    Thread.sleep(20)
                }
                catch (e:InterruptedException) {
                    e.printStackTrace()
                }
            }
        }.start()
    }
}