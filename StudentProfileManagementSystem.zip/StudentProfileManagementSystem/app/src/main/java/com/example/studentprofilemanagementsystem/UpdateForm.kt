package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UpdateForm : AppCompatActivity() {

    lateinit var StudentDb : StudentDatabase
    lateinit var viewModel: StudentViewModel
    
    @SuppressLint("MissingInflatedId", "CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_form)

        StudentDb = StudentDatabase.getDatabase(this)

        val et1 = findViewById<EditText>(R.id.updateReg)
        val show = findViewById<Button>(R.id.show)
        val updateDone = findViewById<Button>(R.id.btn)

        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(StudentViewModel::class.java)
        show.setOnClickListener {
            if(et1.text.toString().isNotEmpty()){
                GlobalScope.launch {
                    val cl = viewModel.getCount2(et1.text.toString())
                    if (cl != 0) {
                        showview()
                    }else{
                        giveToast()
                    }
                }
            }else{
                Toast.makeText(this, "Enter Reg No", Toast.LENGTH_SHORT).show()
            }
        }
        updateDone.setOnClickListener {
            val formName = findViewById<EditText>(R.id.formName).text.toString()
            val formCourse = findViewById<EditText>(R.id.formCourse).text.toString()
            val formYear = findViewById<EditText>(R.id.formYear).text.toString()
            val formGender = findViewById<EditText>(R.id.formGender).text.toString()
            val formAddress = findViewById<EditText>(R.id.formAddress).text.toString()
            val formCgpa = findViewById<EditText>(R.id.formCgpa).text.toString()
            val formReg = findViewById<EditText>(R.id.updateReg).text.toString()
            if(formName.isNotEmpty() && formYear.isNotEmpty() && formCourse.isNotEmpty() && formGender.isNotEmpty() && formAddress.isNotEmpty()
                && formCgpa.isNotEmpty()){
                viewModel.Update(formName,formCourse,formYear,formGender,formAddress,formCgpa,formReg)
                Toast.makeText(this, "Updated Successfully",Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this, "Fill All Values", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun showview() {
        withContext(Dispatchers.Main){
            sho()
        }
    }

    private fun sho() {
        val lin = findViewById<LinearLayout>(R.id.lin)
        lin.visibility = View.VISIBLE
    }

    private suspend fun giveToast() {
        withContext(Dispatchers.Main){
            tos()
        }
    }

    private fun tos() {
        Toast.makeText(this, "No Student Found", Toast.LENGTH_SHORT).show()
        val lin = findViewById<LinearLayout>(R.id.lin)
        lin.visibility = View.GONE
    }
}