package com.example.studentprofilemanagementsystem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Login_Page : AppCompatActivity() {

    lateinit var viewModel: StudentViewModel
    lateinit var StudentDb : StudentDatabase

//    private var flag:Int = 0
    lateinit var st1:Student

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        StudentDb = StudentDatabase.getDatabase(this)

        viewModel = ViewModelProvider(this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(StudentViewModel::class.java)

        val et1 = findViewById<EditText>(R.id.username)
        val et2 = findViewById<EditText>(R.id.password)
        val btn = findViewById<Button>(R.id.loginButton)

//        val btn2 = findViewById<TextView>(R.id.signupText)
//        btn2.setOnClickListener {
//            val intent = Intent(this,registerorm::class.java)
//            startActivity(intent)
//        }
        
        btn.setOnClickListener {
            if(et1.text.toString().isNotEmpty() && et2.text.toString().isNotEmpty()) {
                if (et1.text.toString() == "subhita" && et2.text.toString() == "1200") {
                    val intent = Intent(this, Admin_View::class.java)
                    startActivity(intent)
                }
                else{
                    GlobalScope.launch {
                        val cl = viewModel.findCount(et1.text.toString(),et2.text.toString())
                        if (cl != 0) {
                            val st = StudentDb. getStudentDao().findByName(et1.text.toString(),et2.text.toString())!!
                            setSt1(st)
                        }else{
                            giveToast()
                        }
                    }
                }
            }
            else {
                Toast.makeText(this, "Enter Data", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun giveToast() {
        withContext(Dispatchers.Main){
            toastt()
        }
    }

    private fun toastt() {
        Toast.makeText(this, "No student found", Toast.LENGTH_SHORT).show()
    }

    private suspend fun setSt1(st: Student) {
        withContext(Dispatchers.Main){
            setst1(st)
        }
    }

    private fun setst1(st: Student) {
        st1 = st
        val name = st1.name
        val reg = st1.reg
        val course = st1.course
        val year = st1.year
        val gender = st1.gender
        val address = st1.address
        val cgpa = st1.cgpa
        val intent = Intent(this,FirstScreen::class.java)
        intent.putExtra("name",name)
        intent.putExtra("reg",reg)
        intent.putExtra("course",course)
        intent.putExtra("year",year)
        intent.putExtra("gender",gender)
        intent.putExtra("address",address)
        intent.putExtra("cgpa",cgpa)
        startActivity(intent)
    }
}