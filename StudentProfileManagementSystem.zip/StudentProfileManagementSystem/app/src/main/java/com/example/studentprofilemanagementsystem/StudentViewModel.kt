package com.example.studentprofilemanagementsystem

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import androidx.room.Update
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StudentViewModel(application: Application):AndroidViewModel(application) {

    val allStudent : LiveData<List<Student>>

    private val repository:StudentRepository

    init{
        val dao = StudentDatabase.getDatabase(application).getStudentDao()
        repository = StudentRepository(dao)
        allStudent = repository.allStudent

    }

    fun insertStudent(student: Student) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(student)
    }
//    fun deleteStudent(student: Student) = viewModelScope.launch(Dispatchers.IO) {
//        repository.delete(student)
//    }

    fun Update(msg:String,c:String,y:String,g:String,a:String,cg:String,no:String) = viewModelScope.launch(Dispatchers.IO) {
        repository.updateOne(msg,c,y,g,a,cg,no)
    }

    fun deleteOne(roll:String) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteOne(roll)
    }

    suspend fun findStudent(msg:String, no:String):Student?{
        return repository.getstudent(msg,no)
    }
    suspend fun findCount(msg:String, no:String):Int?{
        return repository.getcount(msg,no)
    }
    suspend fun getCount2(no: String):Int?{
        return repository.getcount2(no)
    }

}