package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: StudentViewModel
    lateinit var StudentDb: StudentDatabase

    @SuppressLint("MissingInflatedId", "WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        StudentDb = StudentDatabase.getDatabase(this)

        val btn = findViewById<Button>(R.id.btn)
        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        ).get(StudentViewModel::class.java)

        btn.setOnClickListener {
            var stName = findViewById<EditText>(R.id.formName).text.toString()
            val stReg = findViewById<EditText>(R.id.formReg).text.toString()
            val stCourse = findViewById<EditText>(R.id.formCourse).text.toString()
            val stYear = findViewById<EditText>(R.id.formYear).text.toString()
            val stGender = findViewById<EditText>(R.id.formGender).text.toString()
            val stAddress = findViewById<EditText>(R.id.formAddress).text.toString()
            val stCgpa = findViewById<EditText>(R.id.formCgpa).text.toString()

            if (stName.isNotEmpty() && stReg.isNotEmpty() && stCourse.isNotEmpty() && stYear.isNotEmpty() && stGender.isNotEmpty()
                && stAddress.isNotEmpty() && stCgpa.isNotEmpty()) {
                GlobalScope.launch {
                    val cl = viewModel.getCount2(stReg)
                    if (cl != 0) {
                        showview()
                    }else{
                        viewModel.insertStudent(Student(stName, stReg,stCourse,stYear,stGender,stAddress,stCgpa))
                        findViewById<EditText>(R.id.formName).text.clear()
                        findViewById<EditText>(R.id.formReg).text.clear()
                        findViewById<EditText>(R.id.formCourse).text.clear()
                        findViewById<EditText>(R.id.formYear).text.clear()
                        findViewById<EditText>(R.id.formGender).text.clear()
                        findViewById<EditText>(R.id.formAddress).text.clear()
                        findViewById<EditText>(R.id.formCgpa).text.clear()
                        giveToast()
                    }
                }
            } else {
                Toast.makeText(this, "Fill All Values", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun giveToast() {
        withContext(Dispatchers.Main) {
            givetoast()
        }
    }

    private fun givetoast() {
        Toast.makeText(this, "Added successfully", Toast.LENGTH_SHORT).show()
    }

    suspend private fun showview() {
        withContext(Dispatchers.Main){
            giveInfo()
        }
    }

    private fun giveInfo() {
        Toast.makeText(this, "Alredy Registered with Same Registreation No", Toast.LENGTH_SHORT).show()
    }

}
