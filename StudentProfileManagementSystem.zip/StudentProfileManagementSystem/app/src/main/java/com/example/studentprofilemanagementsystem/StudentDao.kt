package com.example.studentprofilemanagementsystem

import androidx.core.location.LocationRequestCompat.Quality
import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface StudentDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(student:Student)

    @Delete
    suspend fun delete(student:Student)

    @Query("DELETE FROM student_table WHERE reg LIKE:regno ")
    suspend fun deleteOne(regno: String)

    @Query("UPDATE student_table SET name=:msg, course=:c, year=:y, gender=:g, address=:a,cgpa=:cg WHERE reg LIKE:no")
    suspend fun update(msg:String,c:String,y:String,g:String,a:String,cg:String,no:String)

    @Query("SELECT * FROM student_table ORDER BY id ASC")
    fun getAllStudent():LiveData<List<Student>>

    @Query("SELECT COUNT(*) FROM student_table WHERE name LIKE :msg AND reg LIKE :no")
    suspend fun countStudent(msg:String,no:String):Int?

    @Query("SELECT COUNT(*) FROM student_table WHERE reg LIKE :no")
    suspend fun countStudent2(no:String):Int?

    @Query("SELECT * FROM student_table WHERE name LIKE :msg AND reg LIKE :no LIMIT 1")
    suspend fun findByName(msg:String,no:String) : Student?

    @Query("SELECT * FROM student_table WHERE reg LIKE :no LIMIT 1")
    suspend fun findByName2(no:String) : Student?
}