package com.example.studentprofilemanagementsystem

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ShowAll : AppCompatActivity() {

    lateinit var viewModel: StudentViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_all)

        val rcv = findViewById<RecyclerView>(R.id.rcv)

        rcv.layoutManager = LinearLayoutManager(this)
        val adapter = StudentRVAdapter(this)
        rcv.adapter = adapter

        viewModel = ViewModelProvider(this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(StudentViewModel::class.java)

        viewModel.allStudent.observe(this, Observer { list->
            list?.let{
                adapter.updateList(it)
            }
        })
    }
}