package com.example.studentprofilemanagementsystem

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_table")
class Student(@ColumnInfo(name="name")val name:String,
              @ColumnInfo(name="reg")val reg:String,
              @ColumnInfo(name="course")val course:String,
              @ColumnInfo(name="year")val year:String,
              @ColumnInfo(name="gender")val gender:String,
              @ColumnInfo(name="address")val address:String,
              @ColumnInfo(name="cgpa")val cgpa:String,
              ) {
    @PrimaryKey(autoGenerate = true) var id = 0
}