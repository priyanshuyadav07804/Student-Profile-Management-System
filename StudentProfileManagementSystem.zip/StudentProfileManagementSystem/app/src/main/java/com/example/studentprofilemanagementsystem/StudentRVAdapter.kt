package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.content.Context
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class StudentRVAdapter(private val context: Context):RecyclerView.Adapter<StudentRVAdapter.StudentViewHolder>() {

    private val allStudent = ArrayList<Student>()

    inner class StudentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val textView = itemView.findViewById<TextView>(R.id.stName)
        val reg = itemView.findViewById<TextView>(R.id.stReg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):StudentViewHolder {
        val viewHolder = StudentViewHolder(LayoutInflater.from(context).inflate(R.layout.item_student,parent,false))
        return viewHolder
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: StudentRVAdapter.StudentViewHolder, position: Int) {
        val currentStudent = allStudent[position]
        holder.textView.text = "Name : " +currentStudent.name
        holder.reg.text = "Reg No : "+currentStudent.reg
    }

    override fun getItemCount(): Int {
        return allStudent.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateList(newList: List<Student>){
        allStudent.clear()
        allStudent.addAll(newList)
        notifyDataSetChanged()
    }

}