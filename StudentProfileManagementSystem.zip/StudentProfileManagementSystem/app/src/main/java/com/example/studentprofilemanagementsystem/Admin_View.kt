package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout

class Admin_View : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_view2)


        val adminRegister = findViewById<FrameLayout>(R.id.adminRegister)
        adminRegister.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

        val adminUpdate = findViewById<FrameLayout>(R.id.adminUpdate)
        adminUpdate.setOnClickListener {
            val intent = Intent(this,UpdateForm::class.java)
            startActivity(intent)
        }

        val adminShow = findViewById<FrameLayout>(R.id.adminShow)
        adminShow.setOnClickListener {
            val intent = Intent(this,ShowAll::class.java)
            startActivity(intent)
        }

        val adminDelte = findViewById<FrameLayout>(R.id.adminDelete)
        adminDelte.setOnClickListener {
            val intent = Intent(this,DeleteForm::class.java)
            startActivity(intent)
        }

        val showOne = findViewById<FrameLayout>(R.id.adminShowOne)
        showOne.setOnClickListener {
            val intent = Intent(this,SHowOne::class.java)
            startActivity(intent)
        }
    }
}