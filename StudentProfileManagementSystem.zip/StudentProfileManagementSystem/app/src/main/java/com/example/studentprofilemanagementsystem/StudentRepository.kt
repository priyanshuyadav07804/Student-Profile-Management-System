package com.example.studentprofilemanagementsystem

import androidx.lifecycle.LiveData

class StudentRepository(private val StudentDao : StudentDao) {

    val allStudent: LiveData<List<Student>> = StudentDao.getAllStudent()

    suspend fun insert(student: Student){
        StudentDao.insert(student)
    }

//    suspend fun delete(student: Student){
//        StudentDao.delete(student)
//    }

    suspend fun updateOne(msg:String,c:String,y:String,g:String,a:String,cg:String,no:String){
        StudentDao.update(msg,c,y,g,a,cg,no)
    }

    suspend fun deleteOne(roll:String){
        StudentDao.deleteOne(roll)
    }

    suspend fun getstudent(msg:String,no:String):Student?{
        return StudentDao.findByName(msg, no)
    }
    suspend fun getstudent2(no:String):Student?{
        return StudentDao.findByName2(no)
    }
    suspend fun getcount(msg:String,no:String):Int?{
        return StudentDao.countStudent(msg, no)
    }
    suspend fun getcount2(no:String):Int?{
        return StudentDao.countStudent2(no)
    }





}