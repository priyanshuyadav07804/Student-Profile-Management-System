package com.example.studentprofilemanagementsystem

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DeleteForm : AppCompatActivity() {
    lateinit var StudentDb : StudentDatabase
    lateinit var viewModel: StudentViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_form)

        StudentDb = StudentDatabase.getDatabase(this)
        viewModel = ViewModelProvider(this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(StudentViewModel::class.java)

        val et1 = findViewById<EditText>(R.id.deleteEt)
        
        val btn = findViewById<Button>(R.id.deleteDone)
        
        btn.setOnClickListener { 
            if(et1.text.toString().isNotEmpty()){
                if(et1.text.toString().isNotEmpty()){
                    GlobalScope.launch {
                        val cl = viewModel.getCount2(et1.text.toString())
                        if (cl != 0) {
                            val st = StudentDb. getStudentDao().findByName2(et1.text.toString())!!
                            showview(st)
                        }else{
                            giveToast()
                        }
                    }
                }else{
                    Toast.makeText(this, "Enter Reg No", Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(this, "Enter Data", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun showview(st: Student) {
        withContext(Dispatchers.Main){
            alertDialog(st)
        }
    }

    private fun alertDialog(st: Student) {
        val et1 = findViewById<EditText>(R.id.deleteEt).text.toString()
        val details = "Name: ${st.name} \nReg no: ${st.reg}"
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Do Yo Want To Delete Student?")
        builder.setMessage(details)
        builder.setPositiveButton("OK") { dialog, which ->
            // handle OK button click
            viewModel.deleteOne(et1)
            Toast.makeText(this, "Deleted Successfully", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("Cancel") { dialog, which ->
            // handle Cancel button click
            Toast.makeText(this, "Canceled", Toast.LENGTH_SHORT).show()
        }
        val dialog = builder.create()
        dialog.show()
    }

    private suspend fun giveToast() {
        withContext(Dispatchers.Main){
            tos()
        }
    }

    private fun tos() {
        Toast.makeText(this, "No Student Found", Toast.LENGTH_SHORT).show()
    }
}