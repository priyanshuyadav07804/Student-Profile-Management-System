package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.*


class FirstScreen : AppCompatActivity() {

    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_screen)

        val stName = findViewById<TextView>(R.id.stName)
        val stReg = findViewById<TextView>(R.id.stReg)
        val stYear = findViewById<TextView>(R.id.stYear)
        val stCourse = findViewById<TextView>(R.id.stCourse)
        val stGender = findViewById<TextView>(R.id.stGender)
        val stAddress = findViewById<TextView>(R.id.stAddress)
        val stcgpa = findViewById<TextView>(R.id.stCgpa)

        stName.text ="Name :      "+intent.getStringExtra("name")
        stReg.text = "Reg no :    "+ intent.getStringExtra("reg")
        stYear.text = "Year :       "+ intent.getStringExtra("year")
        stCourse.text = "Course:     "+intent.getStringExtra("course")
        stGender.text = "Gender :    "+intent.getStringExtra("gender")
        stAddress.text = "Address :   "+intent.getStringExtra("address")
        stcgpa.text = "CGPA :      "+intent.getStringExtra("cgpa")





    }
}