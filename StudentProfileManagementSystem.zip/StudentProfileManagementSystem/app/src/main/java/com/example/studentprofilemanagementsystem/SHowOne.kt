package com.example.studentprofilemanagementsystem

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SHowOne : AppCompatActivity() {
    lateinit var StudentDb : StudentDatabase
    lateinit var viewModel: StudentViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_one)

        StudentDb = StudentDatabase.getDatabase(this)
        val et1 = findViewById<EditText>(R.id.updateReg)
        val show = findViewById<Button>(R.id.show)

        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(StudentViewModel::class.java)
        show.setOnClickListener {
            if(et1.text.toString().isNotEmpty()){
                GlobalScope.launch {
                    val cl = viewModel.getCount2(et1.text.toString())
                    if (cl != 0) {
                        val st = StudentDb. getStudentDao().findByName2(et1.text.toString())!!
                        showview(st)
                    }else{
                        giveToast()
                    }
                }
            }else{
                Toast.makeText(this, "Enter Reg No", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun showview(st:Student) {
        withContext(Dispatchers.Main){
            sho(st)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun sho(st: Student) {
        val lin = findViewById<LinearLayout>(R.id.lin2)
        lin.visibility = View.VISIBLE
        val stName = findViewById<TextView>(R.id.stName)
        val stCourse = findViewById<TextView>(R.id.stCourse)
        val stYear = findViewById<TextView>(R.id.stYear)
        val stGender = findViewById<TextView>(R.id.stGender)
        val stAddress = findViewById<TextView>(R.id.stAddress)
        val stCgpa = findViewById<TextView>(R.id.stCgpa)
        val stReg = findViewById<TextView>(R.id.stReg2)

        stName.text ="Name :      "+ st.name
        stReg.text = "Reg no :    "+ st.reg
        stYear.text = "Year :         "+ st.year
        stCourse.text = "Course:     "+ st.course
        stGender.text = "Gender :    "+ st.gender
        stAddress.text = "Address :   "+ st.address
        stCgpa.text = "CGPA :      "+ st.cgpa

    }

    private suspend fun giveToast() {
        withContext(Dispatchers.Main){
            tos()
        }
    }

    private fun tos() {
        Toast.makeText(this, "No Student Found", Toast.LENGTH_SHORT).show()
        val lin = findViewById<LinearLayout>(R.id.lin2)
        lin.visibility = View.GONE
    }
}